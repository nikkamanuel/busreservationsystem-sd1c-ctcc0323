import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class PassengerDetails extends JPanel {

    JTextField firstNameField;
    JTextField middleNameField;
    JTextField lastNameField;
    JTextField emailField;
    JTextField contactNumberField;
    JTextField addressField;
    JButton nextButton;

    public PassengerDetails() {
        setLayout(null); // Use null layout

        JPanel formPanel = new JPanel(null);
        formPanel.setPreferredSize(new Dimension(700, 100));
        formPanel.setBackground(new Color(238, 238, 238));

        Border bottomBorder = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK);

        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(20, 30, 80, 20);
        firstNameField = new JTextField();
        firstNameField.setBounds(20, 60, 200, 20);
        firstNameField.setBorder(bottomBorder);
        firstNameField.setBackground(new Color(238, 238, 238));
        formPanel.add(firstNameLabel);
        formPanel.add(firstNameField);

        JLabel middleNameLabel = new JLabel("Middle Name:");
        middleNameLabel.setBounds(20, 90, 200, 20);
        middleNameField = new JTextField();
        middleNameField.setBounds(20, 120, 200, 20);
        middleNameField.setBorder(bottomBorder);
        middleNameField.setBackground(new Color(238, 238, 238));
        formPanel.add(middleNameLabel);
        formPanel.add(middleNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(20, 150, 80, 20);
        lastNameField = new JTextField();
        lastNameField.setBounds(20, 180, 200, 20);
        lastNameField.setBorder(bottomBorder);
        lastNameField.setBackground(new Color(238, 238, 238));
        formPanel.add(lastNameLabel);
        formPanel.add(lastNameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(350, 30, 80, 20);
        emailField = new JTextField();
        emailField.setBounds(350, 60, 200, 20);
        emailField.setBorder(bottomBorder);
        emailField.setBackground(new Color(238, 238, 238));
        formPanel.add(emailLabel);
        formPanel.add(emailField);

        JLabel contactNumberLabel = new JLabel("Contact Number:");
        contactNumberLabel.setBounds(350, 90, 100, 20);
        contactNumberField = new JTextField();
        contactNumberField.setBounds(350, 120, 200, 20);
        contactNumberField.setBorder(bottomBorder);
        contactNumberField.setBackground(new Color(238, 238, 238));
        formPanel.add(contactNumberLabel);
        formPanel.add(contactNumberField);

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setBounds(350, 150, 80, 20);
        addressField = new JTextField();
        addressField.setBounds(350, 180, 200, 20);
        addressField.setBorder(bottomBorder);
        addressField.setBackground(new Color(238, 238, 238));
        formPanel.add(addressLabel);
        formPanel.add(addressField);

        // Add formPanel
        formPanel.setBounds(100, 40, 700, 220); // Adjusted position and size
        add(formPanel);

        // Next Button
        nextButton = new JButton("Next");
        nextButton.setBounds(500, 290, 100, 30);
        nextButton.setUI(new RoundedButtonUI(Color.WHITE, new Color(28, 175, 207), 20));
        nextButton.setBorderPainted(false);
        add(nextButton);

        // Action listener for Next Button
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    showPopUpInformation(); // Call method to display popup
                } else {
                    displayError("Please fill in all required fields.");
                }
            }
        });
    }

    // Method to validate form fields
    private boolean validateFields() {
        if (firstNameField.getText().isEmpty() ||
            lastNameField.getText().isEmpty() ||
            emailField.getText().isEmpty() ||
            contactNumberField.getText().isEmpty() ||
            addressField.getText().isEmpty()) {
            return false;
        }
        return true;
    }

    // Method to display popup with passenger information
    private void showPopUpInformation() {
        // Example data (replace with actual data from fields)
        String date = "2024-06-17";
        String route = "Example Route";
        String boardingPoint = "Example Boarding Point";
        String droppingPoint = "Example Dropping Point";
        String seatNumbers = "A1, A2";
        String departureTime = "08:00 AM";
        String passengerName = firstNameField.getText() + " " + middleNameField.getText() + " " + lastNameField.getText();
        String mobile = contactNumberField.getText();
        String email = emailField.getText();
        String seatNo = "A1";
        int fare = 609;
        int reservationFee = 50;
        int subtotal = fare + reservationFee;

        // Show popup
        SwingUtilities.invokeLater(() -> new PopUp_Information((BusTicketingSystem) getMainFrame(), date, route, boardingPoint, droppingPoint, seatNumbers,
                departureTime, passengerName, mobile, email, seatNo, fare, reservationFee, subtotal));
    }

    // Helper method to get the main frame (used for positioning popup)
    private JFrame getMainFrame() {
        return (JFrame) SwingUtilities.getWindowAncestor(this);
    }

    void displayError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Custom ButtonUI for creating rounded buttons with custom colors and no border
    static class RoundedButtonUI extends BasicButtonUI {
        private final Color foreground;
        private final Color background;
        private final int arc;

        RoundedButtonUI(Color foreground, Color background, int arc) {
            this.foreground = foreground;
            this.background = background;
            this.arc = arc;
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            AbstractButton button = (AbstractButton) c;
            int width = button.getWidth();
            int height = button.getHeight();

            // Create round shape
            Shape shape = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, arc, arc);
            g2d.setColor(button.getModel().isPressed() ? background.darker() : background);
            g2d.fill(shape);

            g2d.setColor(foreground);
            FontMetrics fm = g2d.getFontMetrics();
            Rectangle textRect = fm.getStringBounds(button.getText(), g2d).getBounds();
            int x = (width - textRect.width) / 2;
            int y = (height - textRect.height) / 2 + fm.getAscent();
            g2d.drawString(button.getText(), x, y);

            g2d.dispose();
        }

        @Override
        public Dimension getPreferredSize(JComponent c) {
            return new Dimension(100, 30);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Passenger Details");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900, 500);

            PassengerDetails passengerDetailsPanel = new PassengerDetails();
            passengerDetailsPanel.setBounds(0, 0, 900, 500); // Center panel in frame
            frame.add(passengerDetailsPanel);

            frame.setVisible(true);
        });
    }
}
