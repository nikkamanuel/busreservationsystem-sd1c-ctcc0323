import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.plaf.basic.BasicButtonUI;

public class Header extends JPanel {

    public Header() {
        setLayout(null); // Use null layout for manual positioning of components
        setPreferredSize(new Dimension(900, 60)); // Set preferred size for the header panel
        
        addTitleLabel();
        addMenuButtons();
        addLogoImage();
    }

    private void addTitleLabel() {
        JLabel titleLabel = new JLabel("PASSENJOUR |");
        titleLabel.setFont(new Font("Templar Shield Title", Font.BOLD, 30));
        titleLabel.setBounds(100, 15, 300, 40);
        add(titleLabel);
    }

    private void addMenuButtons() {
        String[] menuItems = {"ABOUT US", "OUR BUSES", "TOUR PACKAGES"};
        int xPosition = 350;
        int buttonWidth = 90;
        int buttonHeight = 20;
        int horizontalGap = 2;

        for (String item : menuItems) {
            JButton menuButton = new JButton(item);
            menuButton.setBounds(xPosition, 30, buttonWidth, buttonHeight);
            menuButton.setFont(new Font("Trebuchet MS", Font.BOLD, 10));
            menuButton.setBorder(null);
            menuButton.setForeground(Color.GRAY);
            menuButton.setBackground(new Color(238, 238, 238));
            add(menuButton);
            xPosition += buttonWidth + horizontalGap;

            menuButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    menuButton.setForeground(Color.BLACK);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    menuButton.setForeground(Color.GRAY);
                }
            });

            menuButton.addActionListener(e -> {
                int choice = getMenuItemIndex(item);
                switch (choice) {
                    case 0:
                        showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\AboutUs.jpg", "About Us");
                        break;
                    case 1:
                        showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\OurBuses.jpg", "Our Buses");
                        break;
                    case 2:
                        showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\TourPackages.jpg", "Tour Packages");
                        break;
                }
            });
        }

        JButton contactButton = new JButton("CONTACT US");
        contactButton.setBounds(xPosition + 80, 30, buttonWidth, buttonHeight);
        contactButton.setFont(new Font("Trebuchet MS", Font.BOLD, 10));
        contactButton.setBorderPainted(false);
        contactButton.setFocusPainted(false);
        contactButton.setContentAreaFilled(false);
        contactButton.setForeground(Color.BLACK);
        contactButton.setBackground(new Color(28, 175, 207));
        contactButton.setUI(new RoundedButtonUI());
        contactButton.setPreferredSize(new Dimension(buttonWidth, buttonHeight));

        add(contactButton);

        contactButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                contactButton.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                contactButton.setForeground(Color.BLACK);
            }
        });

        contactButton.addActionListener(e -> {
            // Show "Contact Us" image
            showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\ContactUs.jpg", "Contact Us");
        });
    }

    static class RoundedButtonUI extends BasicButtonUI {
        private static final int arc = 20;

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            AbstractButton button = (AbstractButton) c;
            int width = button.getWidth();
            int height = button.getHeight();

            Shape shape = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, arc, arc);
            g2d.setColor(button.getBackground());
            g2d.fill(shape);

            g2d.setColor(button.getForeground());
            g2d.setFont(c.getFont());

            FontMetrics fm = g2d.getFontMetrics();
            Rectangle textRect = fm.getStringBounds(button.getText(), g2d).getBounds();
            int x = (width - textRect.width) / 2;
            int y = (height - textRect.height) / 2 + fm.getAscent();
            g2d.drawString(button.getText(), x, y);

            g2d.dispose();
        }
    }

    private void addLogoImage() {
        ImageIcon icon = new ImageIcon("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\Logo_Resized.png");
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setBounds(35, 5, icon.getIconWidth(), icon.getIconHeight());
        add(imageLabel);
    }

    private int getMenuItemIndex(String menuItem) {
        switch (menuItem) {
            case "ABOUT US":
                return 0;
            case "OUR BUSES":
                return 1;
            case "TOUR PACKAGES":
                return 2;
            default:
                return -1;
        }
    }

    private void showImage(String imagePath, String title) {
        ImageIcon icon = new ImageIcon(imagePath);
        
        // Get the original image dimensions
        int originalWidth = icon.getIconWidth();
        int originalHeight = icon.getIconHeight();
        
        // Maximum dimensions for the displayed image
        int maxWidth = 600;
        int maxHeight = 500;
        
        // Calculate scaling factors to fit within maxWidth x maxHeight
        double widthScale = (double) maxWidth / originalWidth;
        double heightScale = (double) maxHeight / originalHeight;
        double scale = Math.min(widthScale, heightScale);
        
        // Calculate scaled dimensions
        int scaledWidth = (int) (originalWidth * scale);
        int scaledHeight = (int) (originalHeight * scale);
        
        // Scale the ImageIcon
        Image scaledImage = icon.getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        
        // Create a JLabel to display the scaled image
        JLabel imageLabel = new JLabel(scaledIcon);
        
        // Create a JDialog to show the image without an "OK" button
        JDialog dialog = new JDialog();
        dialog.setTitle(title);
        dialog.setModal(true);
        dialog.getContentPane().add(imageLabel);
        dialog.pack();
        dialog.setLocationRelativeTo(null); // Center the dialog on screen
        dialog.setVisible(true);
    }
}
