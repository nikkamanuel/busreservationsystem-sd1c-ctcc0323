import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class DeluxeBusPanel extends JPanel {

    private static final int MAX_SEATS = 30; // Maximum number of seats in a deluxe bus
    private int seatNumber = 1; // Track seat number
    private boolean[] seatsAvailable; // Array to track seat availability
    private boolean seatSelected;

    public DeluxeBusPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Add padding
        
        // Initialize availability of seats randomly
        seatsAvailable = generateRandomAvailableSeats(MAX_SEATS);

        JLabel header = new JLabel("DELUXE", JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        add(header, BorderLayout.NORTH);

        JPanel seatsPanel = new JPanel();
        seatsPanel.setLayout(new GridLayout(6, 5, 10, 10)); // 6 rows, 5 columns with 10px spacing

        // First row with driver seat on the left
        JButton driverButton = createDriverSeatButton();
        seatsPanel.add(driverButton);
        for (int col = 0; col < 4; col++) {
            seatsPanel.add(new JLabel()); // Empty labels for spacing
        }

        // Rows with 2 seats on the left and 2 seats on the right
        for (int row = 1; row <= 5; row++) {
            if (row <= 4) { // 4 rows of 2x2 seats
                addRowOfSeats(seatsPanel, 2);
                seatsPanel.add(new JLabel()); // Space in the middle
                addRowOfSeats(seatsPanel, 2);
            } else { // Last row with 5 seats
                addRowOfSeats(seatsPanel, 5);
            }
        }

        JScrollPane scrollPane = new JScrollPane(seatsPanel);
        add(scrollPane, BorderLayout.CENTER);

        // Next button
        JButton nextButton = createNextButton();
        JPanel bottomPanel = createBottomPanel(nextButton);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    private JButton createDriverSeatButton() {
        JButton driverButton = new JButton("Driver");
        driverButton.setEnabled(false);
        driverButton.setBackground(Color.GRAY);
        return driverButton;
    }

    private void addRowOfSeats(JPanel seatsPanel, int numberOfSeats) {
        for (int col = 0; col < numberOfSeats; col++) {
            JButton seatButton = new JButton(String.valueOf(seatNumber));
            seatButton.setPreferredSize(new Dimension(60, 60)); // Larger size
            seatButton.addActionListener(new SeatButtonActionListener());

            // Check if seat is available
            if (seatsAvailable[seatNumber - 1]) {
                seatButton.setBackground(Color.GREEN); // Available seats are green
            } else {
                seatButton.setBackground(Color.RED); // Reserved seats are red
                seatButton.setEnabled(false); // Reserved seats cannot be selected
            }

            seatsPanel.add(seatButton);
            seatNumber++;

            if (seatNumber > MAX_SEATS) {
                break;
            }
        }
    }

    private JButton createNextButton() {
        JButton nextButton = new JButton("Next");
        nextButton.setFont(new Font("Arial", Font.BOLD, 14));
        nextButton.setEnabled(false); // Initially disabled
        nextButton.addActionListener(e -> {
      Window window = SwingUtilities.getWindowAncestor(this);
            if (window instanceof JDialog) {
                JDialog dialog = (JDialog) window;
                dialog.dispose(); // Close the dialog
            }
        });
        return nextButton;
    }

    private JPanel createBottomPanel(JButton nextButton) {
        JPanel legendPanel = createLegendPanel();
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.X_AXIS));
        bottomPanel.add(legendPanel); // Add legend panel
        bottomPanel.add(Box.createHorizontalGlue()); // Add glue to push next button to the right
        bottomPanel.add(nextButton); // Add next button
        return bottomPanel;
    }

    private JPanel createLegendPanel() {
        JPanel legendPanel = new JPanel();
        legendPanel.setLayout(new FlowLayout(FlowLayout.LEADING, 20, 5)); // Used FlowLayout with LEADING alignment
        legendPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 5));

        JLabel availableLabel = createLegendLabel(" Available ", Color.GREEN);
        legendPanel.add(availableLabel);

        JLabel reservedLabel = createLegendLabel(" Sold ", Color.RED);
        legendPanel.add(reservedLabel);

        JLabel selectedLabel = createLegendLabel(" Selected ", Color.YELLOW);
        legendPanel.add(selectedLabel);

        return legendPanel;
    }

    private JLabel createLegendLabel(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setOpaque(true);
        label.setBackground(color);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        return label;
    }

 private class SeatButtonActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton seatButton = (JButton) e.getSource();
            Color currentColor = seatButton.getBackground();

            if (currentColor == Color.GREEN) {
                seatButton.setBackground(Color.YELLOW);
                seatSelected = true; // Flag that a seat is selected
            } else if (currentColor == Color.YELLOW) {
                seatButton.setBackground(Color.GREEN);
                seatSelected = false; // Deselect the seat
            }

            checkNextButtonEnabled(); // Check if Next button should be enabled
        }
    }

    private void checkNextButtonEnabled() {
        Component[] components = getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel bottomPanel = (JPanel) component;
                Component[] panelComponents = bottomPanel.getComponents();
                for (Component panelComponent : panelComponents) {
                    if (panelComponent instanceof JButton) {
                        JButton nextButton = (JButton) panelComponent;
                        nextButton.setEnabled(seatSelected);
                        return;
                    }
                }
            }
        }
    }


    private boolean[] generateRandomAvailableSeats(int maxSeats) {
        boolean[] seatsAvailable = new boolean[maxSeats];
        Random random = new Random();

        // For demonstration, randomly reserve some seats
        for (int i = 0; i < maxSeats; i++) {
            seatsAvailable[i] = random.nextBoolean(); // true for available, false for reserved
        }

        return seatsAvailable;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Deluxe Bus Panel Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);
            frame.setLocationRelativeTo(null);

            DeluxeBusPanel panel = new DeluxeBusPanel();
            frame.add(panel);

            frame.setVisible(true);
        });
    }
}
