import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class TicketPanel extends JPanel {

    public TicketPanel() {
        // Set panel layout to GridBagLayout for precise positioning
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add padding around components

        // Create label with thank you message
        JLabel messageLabel = new JLabel("THANK YOU FOR CHOOSING PASSEJOUR!", SwingConstants.CENTER);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 18));

        // Add label to the panel with GridBagLayout constraints
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(messageLabel, gbc);

        // Create button for downloading ticket
        JButton downloadButton = new JButton("Download Ticket");
        downloadButton.setFont(new Font("Arial", Font.PLAIN, 14));

        // Set preferred size to customize dimensions
        downloadButton.setPreferredSize(new Dimension(150, 40));

        // Add action listener to handle button click
        downloadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Action to perform when button is clicked (e.g., initiate ticket download)
                System.out.println("Ticket downloading...");
                // Replace with actual download logic if needed

                // Show a photo pop-up
                showPhotoPopup();
            }
        });

        // Add button to the panel with GridBagLayout constraints for centering
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER; // Center align button
        add(downloadButton, gbc);
    }

    private void showPhotoPopup() {
        // Load an image to display
        try {
            BufferedImage img = ImageIO.read(new File("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\Ticket.jpg")); // Replace with your image path
            ImageIcon icon = new ImageIcon(img);

            // Create a JOptionPane to display the image
            JOptionPane.showMessageDialog(this, new JLabel(icon), "Ticket Image", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load image", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Create a JFrame to hold the TicketPanel
        JFrame frame = new JFrame("Ticket Download");

        // Create an instance of TicketPanel
        TicketPanel ticketPanel = new TicketPanel();

        // Add TicketPanel to the JFrame
        frame.getContentPane().add(ticketPanel);

        // Set JFrame properties
        frame.setSize(900, 500); // Set size of the frame
        frame.setLocationRelativeTo(null); // Center the frame on the screen
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exit when the close button is clicked
        frame.setVisible(true); // Make the frame visible
    }
}
