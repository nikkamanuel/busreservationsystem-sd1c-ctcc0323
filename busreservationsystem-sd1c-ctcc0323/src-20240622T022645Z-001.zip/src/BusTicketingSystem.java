import javax.swing.*;

public class BusTicketingSystem extends JFrame {
    private JPanel contentPane;
    private JTabbedPane tabbedPane;
    private RouteAndSchedulePanel routeAndSchedulePanel;
    private BookSeatPanel bookSeatPanel;
    private PassengerDetails passengerDetailsPanel;
    private PaymentPanel paymentPanel;
    private TicketPanel downloadTicketPanel;
    private Header headerPanel;

    public BusTicketingSystem() {
        setTitle("Bus Ticketing System");
        setSize(900, 500); // Initial size of the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane = new JPanel(null); // Using absolute layout for manual positioning
        setContentPane(contentPane);

        // Create HeaderPanel and set its bounds (manual positioning)
        headerPanel = new Header();
        headerPanel.setBounds(0, 0, 900, 100); // Adjust as needed
        contentPane.add(headerPanel);

        // Create tabbed pane for main content
        tabbedPane = new JTabbedPane();

        // Initialize RouteAndSchedulePanel (Route and Schedule Panel)
        routeAndSchedulePanel = new RouteAndSchedulePanel(this); // Pass reference to this frame
        tabbedPane.addTab("Route and Schedule", routeAndSchedulePanel);

        // Initialize BookSeatPanel (Book Seat Panel)
        bookSeatPanel = new BookSeatPanel();
        tabbedPane.addTab("Book Seat", bookSeatPanel);
        tabbedPane.setEnabledAt(1, false); // Disable the Book Seat tab initially

        // Initialize PassengerDetailsPanel (Passenger Details Panel)
        passengerDetailsPanel = new PassengerDetails();
        tabbedPane.addTab("Passenger Details", passengerDetailsPanel);
        tabbedPane.setEnabledAt(2, false); // Disable the Passenger Details tab initially

        // Initialize PaymentPanel (Payment Panel)
        paymentPanel = new PaymentPanel(this); // Pass reference to this frame
        tabbedPane.addTab("Payment", paymentPanel);
        tabbedPane.setEnabledAt(3, false); // Disable the Payment tab initially

        // Initialize TicketPanel (Download Ticket Panel)
        downloadTicketPanel = new TicketPanel();
        tabbedPane.addTab("Download Ticket", downloadTicketPanel);
        tabbedPane.setEnabledAt(4, false); // Disable the Download Ticket tab initially

        // Set bounds for the tabbed pane (manual positioning)
        tabbedPane.setBounds(0, 100, 900, 500); // Adjust Y position and height as needed
        contentPane.add(tabbedPane);

        setVisible(true);
    }

    // Method to enable and switch to the next tab (Book Seat)
    public void enableNextTab() {
        int currentIndex = tabbedPane.getSelectedIndex();
        tabbedPane.setEnabledAt(currentIndex + 1, true); // Enable next tab
        tabbedPane.setSelectedIndex(currentIndex + 1); // Switch to next tab
    }

    // Method to switch to the Book Seat tab
    public void switchToBookSeatPanel() {
        tabbedPane.setSelectedIndex(1); // Switch to Book Seat tab
    }

    // Method to switch to the Passenger Details tab
    public void switchToPassengerDetailsPanel() {
        tabbedPane.setSelectedIndex(2); // Switch to Passenger Details tab
        tabbedPane.setEnabledAt(2, true); // Enable Passenger Details tab
    }

    // Method to switch to the Payment tab
    public void switchToPaymentPanel() {
        tabbedPane.setSelectedIndex(3); // Switch to Payment tab
        tabbedPane.setEnabledAt(3, true); // Enable Payment tab
    }

    // Method to switch to the Download Ticket tab
    public void switchToDownloadTicketPanel() {
        tabbedPane.setSelectedIndex(4); // Switch to Download Ticket tab
        tabbedPane.setEnabledAt(4, true); // Enable Download Ticket tab
    }

    // Method to show PopUp_Information and handle confirmation process
    public void showConfirmationDialog(String date, String route, String boardingPoint,
                                       String droppingPoint, String seatNumbers, String departureTime,
                                       String passengerName, String mobile, String email, String seatNo,
                                       int fare, int reservationFee, int subtotal) {

        // Show PopUp_Information dialog
        PopUp_Information dialog = new PopUp_Information(this, date, route, boardingPoint, droppingPoint,
                seatNumbers, departureTime, passengerName, mobile, email, seatNo, fare, reservationFee, subtotal);

        // Check if confirmation is completed and switch to Payment tab
        dialog.setConfirmationCallback(new PopUp_Information.ConfirmationCallback() {
            @Override
            public void confirmationComplete() {
                switchToPaymentPanel(); // Switch to Payment tab upon confirmation completion
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BusTicketingSystem();
        });
    }
}
