import javax.swing.*;
import java.awt.*;

public class SeatBookingPopUp extends JDialog {

    private BusTicketingSystem parentFrame;
    private String busType;

    public SeatBookingPopUp(JFrame parent, String busType) {
        super(parent, "Book Your Seat", true);
        this.parentFrame = (BusTicketingSystem) parent;
        this.busType = busType;

        setSize(500, 450);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel bookingPanel = null;

        // Determine which type of bus panel to create based on busType
        if (busType.equalsIgnoreCase("regular")) {
            bookingPanel = new RegularBusPanel(busType);
        } else if (busType.equalsIgnoreCase("deluxe")) {
            bookingPanel = new DeluxeBusPanel();
        } else if (busType.equalsIgnoreCase("first class")) {
            bookingPanel = new FirstClassBusPanel();
        }

        if (bookingPanel != null) {
            add(bookingPanel, BorderLayout.CENTER);
        }

        // Add window listener to handle closing event
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                enableAndSwitchToPassengerDetailsTab();
            }
        });

        setVisible(true);
    }

    // Method to enable and switch to Passenger Details tab in the main frame
    private void enableAndSwitchToPassengerDetailsTab() {
        parentFrame.switchToPassengerDetailsPanel();
    }
}
