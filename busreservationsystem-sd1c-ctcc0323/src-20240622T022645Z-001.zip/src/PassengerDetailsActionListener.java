import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PassengerDetailsActionListener implements ActionListener {

    private PassengerDetails passengerDetails;

    public PassengerDetailsActionListener(PassengerDetails passengerDetails) {
        this.passengerDetails = passengerDetails;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("Next")) {
            if (validateForm()) {
                // Open pop-up dialog with information
                JOptionPane.showMessageDialog(passengerDetails,
                        "Payment processing logic goes here!", "Payment Details", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (command.equals("Previous")) {
            // Additional action for the Previous button if needed
        }
    }

    private boolean validateForm() {
        if (passengerDetails.firstNameField.getText().trim().isEmpty()) {
            passengerDetails.displayError("First Name is required.");
            return false;
        }
        if (containsNumbers(passengerDetails.firstNameField.getText().trim())) {
            passengerDetails.displayError("First Name should not contain numbers.");
            return false;
        }

        if (passengerDetails.middleNameField.getText().trim().isEmpty()) {
            passengerDetails.displayError("Middle Name is required.");
            return false;
        }
        if (containsNumbers(passengerDetails.middleNameField.getText().trim())) {
            passengerDetails.displayError("Middle Name should not contain numbers.");
            return false;
        }

        if (passengerDetails.lastNameField.getText().trim().isEmpty()) {
            passengerDetails.displayError("Last Name is required.");
            return false;
        }
        if (containsNumbers(passengerDetails.lastNameField.getText().trim())) {
            passengerDetails.displayError("Last Name should not contain numbers.");
            return false;
        }

        if (passengerDetails.emailField.getText().trim().isEmpty()) {
            passengerDetails.displayError("Email is required.");
            return false;
        }
        if (!isValidEmail(passengerDetails.emailField.getText().trim())) {
            passengerDetails.displayError("Invalid Email format.");
            return false;
        }

        if (passengerDetails.contactNumberField.getText().trim().isEmpty()) {
            passengerDetails.displayError("Contact Number is required.");
            return false;
        }
        if (!isNumeric(passengerDetails.contactNumberField.getText().trim())) {
            passengerDetails.displayError("Contact Number should contain only numbers.");
            return false;
        }

        if (passengerDetails.addressField.getText().trim().isEmpty()) {
            passengerDetails.displayError("Address is required.");
            return false;
        }

        return true;
    }

    private boolean containsNumbers(String text) {
        return text.matches(".*\\d.*");
    }

    private boolean isNumeric(String text) {
        return text.matches("\\d+");
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }
}
