import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.Random;

public class BookSeatPanel extends JPanel {
    private JComboBox<String> classComboBox;
    private JComboBox<String> seatsComboBox;
    private JPanel scrollablePanel;
    private GridBagConstraints gbc; // GridBagConstraints for layout

    public BookSeatPanel() {
        setLayout(new BorderLayout());

        // Initialize scrollablePanel with GridBagLayout
        scrollablePanel = new JPanel(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 10, 5, 10);

        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        addPanel(headerPanel); // Add header panel to scrollablePanel

        // Generate random data and populate the scrollable panel
        generateRandomData();

        // Create JScrollPane for scrollablePanel
        JScrollPane scrollPane = new JScrollPane(scrollablePanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Add scroll pane to this panel
        add(scrollPane, BorderLayout.CENTER);
    }

    // Method to create header panel with filters
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new GridLayout(1, 5, 10, 0));
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel departureTimeLabel = new JLabel("Departure Time", SwingConstants.CENTER);
        headerPanel.add(departureTimeLabel);

        String[] classOptions = {"Class", "Regular", "First Class", "Deluxe"};
        classComboBox = new JComboBox<>(classOptions);
        classComboBox.setPreferredSize(new Dimension(120, 20));
        headerPanel.add(classComboBox);

        String[] seatsOptions = {"Available Seats", "5 - 20", "10 - 25", "15 - 30"};
        seatsComboBox = new JComboBox<>(seatsOptions);
        seatsComboBox.setPreferredSize(new Dimension(120, 20));
        headerPanel.add(seatsComboBox);

        JLabel fareLabel = new JLabel("Fare (PHP)", SwingConstants.CENTER);
        headerPanel.add(fareLabel);

        JLabel actionLabel = new JLabel("Action", SwingConstants.CENTER);
        headerPanel.add(actionLabel);

        Font headerFont = new Font("Arial", Font.BOLD, 14);
        departureTimeLabel.setFont(headerFont);
        fareLabel.setFont(headerFont);
        actionLabel.setFont(headerFont);

        addActionListeners(); // Add action listeners to combo boxes

        return headerPanel;
    }

    // Method to add action listeners to combo boxes
    private void addActionListeners() {
        classComboBox.addActionListener(e -> handleFilterAction());
        seatsComboBox.addActionListener(e -> handleFilterAction());
    }

    // Method to handle filtering based on selected filters
    private void handleFilterAction() {
        String selectedClass = (String) classComboBox.getSelectedItem();
        String selectedSeats = (String) seatsComboBox.getSelectedItem();
        filterRows(selectedClass, selectedSeats);
    }

    // Method to generate random data and populate scrollable panel
    private void generateRandomData() {
        Random random = new Random();
        int numRows = 20; // Number of rows to generate

        for (int i = 0; i < numRows; i++) {
            String departureTime = generateRandomTime();
            String busClass = generateRandomClass();
            int availableSeats = generateRandomSeats(busClass);
            double fare = generateRandomFare(busClass);

            JPanel rowPanel = new JPanel(new GridLayout(1, 5, 10, 0));
            rowPanel.setBorder(new EmptyBorder(5, 10, 5, 10));

            JLabel timeLabel = new JLabel(departureTime, SwingConstants.CENTER);
            JLabel classLabelValue = new JLabel(busClass, SwingConstants.CENTER);
            JLabel seatsLabelValue = new JLabel(String.valueOf(availableSeats), SwingConstants.CENTER);
            JLabel fareLabelValue = new JLabel(formatFare(fare), SwingConstants.CENTER);

            rowPanel.add(timeLabel);
            rowPanel.add(classLabelValue);
            rowPanel.add(seatsLabelValue);
            rowPanel.add(fareLabelValue);

            JButton viewSeatsButton = new JButton("View Seats");
            viewSeatsButton.setPreferredSize(new Dimension(100, 20));
            viewSeatsButton.setHorizontalAlignment(SwingConstants.CENTER);
            viewSeatsButton.addActionListener(e -> {
                String selectedClassValue = classLabelValue.getText();
                openSeatBookingPopup(selectedClassValue);
            });

            rowPanel.add(viewSeatsButton);

            addPanel(rowPanel); // Add row panel to scrollablePanel
        }
    }

    // Method to format fare to two decimal places
    private String formatFare(double fare) {
        DecimalFormat df = new DecimalFormat("#0.00");
        return df.format(fare);
    }

    // Method to open seat booking popup
    private void openSeatBookingPopup(String selectedClass) {
        JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
        new SeatBookingPopUp(parentFrame, selectedClass);
    }

    // Method to filter rows based on selected class and seats
    private void filterRows(String selectedClass, String selectedSeats) {
        Component[] components = scrollablePanel.getComponents();
        for (Component component : components) {
            if (component instanceof JPanel && component != scrollablePanel.getComponent(0)) {
                JPanel rowPanel = (JPanel) component;

                JLabel classLabelValue = (JLabel) rowPanel.getComponent(1);
                JLabel seatsLabelValue = (JLabel) rowPanel.getComponent(2);

                String classValue = classLabelValue.getText();
                String seatsValue = seatsLabelValue.getText();
                int seatsValueInt = Integer.parseInt(seatsValue);

                boolean classMatch = selectedClass.equals("Class") || classValue.equals(selectedClass);
                boolean seatsMatch = selectedSeats.equals("Available Seats") ||
                        (selectedSeats.equals("5 - 20") && seatsValueInt >= 5 && seatsValueInt <= 20) ||
                        (selectedSeats.equals("10 - 25") && seatsValueInt >= 10 && seatsValueInt <= 25) ||
                        (selectedSeats.equals("15 - 30") && seatsValueInt >= 15 && seatsValueInt <= 30);

                rowPanel.setVisible(classMatch && seatsMatch);
            }
        }
        adjustRowAlignment();
    }

    // Method to adjust row alignment within scrollable panel
    private void adjustRowAlignment() {
        Component[] components = scrollablePanel.getComponents();
        for (Component component : components) {
            if (component instanceof JPanel && component != scrollablePanel.getComponent(0)) {
                scrollablePanel.remove(component);
                scrollablePanel.add(component, gbc); // Add with GridBagConstraints to maintain layout
            }
        }
        scrollablePanel.revalidate();
        scrollablePanel.repaint();
    }

    // Method to add panel to scrollable panel with GridBagConstraints
    private void addPanel(JPanel panel) {
        scrollablePanel.add(panel, gbc);
        gbc.gridy++; // Increment y position for next component
    }

    // Generate random departure time
    private String generateRandomTime() {
        Random random = new Random();
        int hour = random.nextInt(12) + 1; // Random hour between 1 and 12
        int minute = random.nextInt(3) * 20; // Random multiple of 20 (0, 20, 40)
        String amPm = random.nextBoolean() ? "AM" : "PM"; // Randomly choose AM or PM

        return String.format("%d:%02d %s", hour, minute, amPm);
    }

    // Generate random bus class
    private String generateRandomClass() {
        Random random = new Random();
        String[] classes = {"Regular", "First Class", "Deluxe"};
        return classes[random.nextInt(classes.length)];
    }

    // Generate random available seats based on bus class
    private int generateRandomSeats(String busClass) {
        Random random = new Random();
        switch (busClass) {
            case "Regular":
                return random.nextInt(37) + 1; // 1 to 37 seats
            case "Deluxe":
                return random.nextInt(21) + 1; // 1 to 21 seats
            case "First Class":
                return random.nextInt(16) + 1; // 1 to 16 seats
            default:
                return 0;
        }
    }

    // Generate random fare based on bus class
    private double generateRandomFare(String busClass) {
        Random random = new Random();
        switch (busClass) {
            case "Regular":
                return random.nextInt(101) + 200.00; // 200.00 to 300.00 PHP
            case "Deluxe":
                return random.nextInt(101) + 301.00; // 301.00 to 400.00 PHP
            case "First Class":
                return random.nextInt(101) + 401.00; // 401.00 to 500.00 PHP
            default:
                return 0.00;
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Book Seat Panel");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(700, 400);

            BookSeatPanel bookSeatPanel = new BookSeatPanel();
            frame.add(bookSeatPanel, BorderLayout.CENTER);

            frame.setVisible(true);
        });
    }
}
