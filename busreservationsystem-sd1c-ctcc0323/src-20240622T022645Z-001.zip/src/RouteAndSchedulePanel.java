import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;

public class RouteAndSchedulePanel extends JPanel {

    private BusTicketingSystem busTicketingSystem;

    public RouteAndSchedulePanel(BusTicketingSystem busTicketingSystem) {
        this.busTicketingSystem = busTicketingSystem;
        // Set layout and add the trip panel to the main panel
        setLayout(null);
        add(createRouteAndSchedulePanel());
    }

    private JPanel createRouteAndSchedulePanel() {
        JPanel tripPanel = new JPanel();
        tripPanel.setBounds(30, 20, 800, 400);
        tripPanel.setLayout(null);

        JLabel tripLabel = new JLabel("SELECT YOUR TRIP");
        tripLabel.setFont(new Font("Arial", Font.BOLD, 16));
        int labelWidth = 200; // Width of the label
        int labelX = (tripPanel.getWidth() - labelWidth) / 2;
        tripLabel.setBounds(labelX, 5, labelWidth, 30);
        tripPanel.add(tripLabel);

        JLabel fromLabel = new JLabel("From");
        fromLabel.setBounds(110, 80, 100, 30);
        tripPanel.add(fromLabel);

        String[] locations = {"Select a location", "BAGUIO", "BALANGA via Highway", "CALOOCAN", "CUBAO",
                "MARIVELES", "OLONGAPO", "SAN FERNANDO, PAMPANGA"};

        JComboBox<String> fromComboBox = new JComboBox<>(locations);
        fromComboBox.setBounds(110, 120, 200, 30);
        tripPanel.add(fromComboBox);

        JLabel toLabel = new JLabel("To");
        toLabel.setBounds(450, 80, 100, 30);
        tripPanel.add(toLabel);

        JComboBox<String> toComboBox = new JComboBox<>(locations);
        toComboBox.setBounds(450, 120, 200, 30);
        tripPanel.add(toComboBox);

        JLabel departDateLabel = new JLabel("Departure Date");
        departDateLabel.setBounds(110, 160, 150, 30);
        tripPanel.add(departDateLabel);

        String[] months = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        Integer[] days = new Integer[31];
        for (int i = 0; i < 31; i++) {
            days[i] = i + 1;
        }
        Integer[] years = new Integer[100];
        for (int i = 0; i < 100; i++) {
            years[i] = 2023 + i;
        }

        JComboBox<String> departMonthComboBox = new JComboBox<>(months);
        JComboBox<Integer> departDayComboBox = new JComboBox<>(days);
        JComboBox<Integer> departYearComboBox = new JComboBox<>(years);

        LocalDate currentDate = LocalDate.now();
        departMonthComboBox.setSelectedIndex(currentDate.getMonthValue() - 1);
        departDayComboBox.setSelectedItem(currentDate.getDayOfMonth());
        departYearComboBox.setSelectedItem(currentDate.getYear());

        departMonthComboBox.setBounds(110, 200, 100, 30);
        departDayComboBox.setBounds(220, 200, 50, 30);
        departYearComboBox.setBounds(280, 200, 80, 30);
        tripPanel.add(departMonthComboBox);
        tripPanel.add(departDayComboBox);
        tripPanel.add(departYearComboBox);

        JLabel returnDateLabel = new JLabel("Return Date");
        returnDateLabel.setBounds(450, 160, 150, 30);
        returnDateLabel.setVisible(false);
        tripPanel.add(returnDateLabel);

        JComboBox<String> returnMonthComboBox = new JComboBox<>(months);
        JComboBox<Integer> returnDayComboBox = new JComboBox<>(days);
        JComboBox<Integer> returnYearComboBox = new JComboBox<>(years);

        returnMonthComboBox.setSelectedIndex(currentDate.getMonthValue() - 1);
        returnDayComboBox.setSelectedItem(currentDate.getDayOfMonth());
        returnYearComboBox.setSelectedItem(currentDate.getYear());

        returnMonthComboBox.setBounds(450, 200, 100, 30);
        returnDayComboBox.setBounds(560, 200, 50, 30);
        returnYearComboBox.setBounds(620, 200, 80, 30);
        returnMonthComboBox.setVisible(false);
        returnDayComboBox.setVisible(false);
        returnYearComboBox.setVisible(false);
        tripPanel.add(returnMonthComboBox);
        tripPanel.add(returnDayComboBox);
        tripPanel.add(returnYearComboBox);

        JRadioButton roundTrip = new JRadioButton("Round Trip");
        roundTrip.setBounds(380, 40, 100, 30);
        tripPanel.add(roundTrip);

        JRadioButton oneWay = new JRadioButton("One Way");
        oneWay.setBounds(280, 40, 100, 30);
        tripPanel.add(oneWay);

        ButtonGroup tripTypeGroup = new ButtonGroup();
        tripTypeGroup.add(roundTrip);
        tripTypeGroup.add(oneWay);

        oneWay.setSelected(true);

        roundTrip.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                returnDateLabel.setVisible(true);
                returnMonthComboBox.setVisible(true);
                returnDayComboBox.setVisible(true);
                returnYearComboBox.setVisible(true);
            }
        });

        oneWay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                returnDateLabel.setVisible(false);
                returnMonthComboBox.setVisible(false);
                returnDayComboBox.setVisible(false);
                returnYearComboBox.setVisible(false);
            }
        });

        class RoundedButton extends JButton {
            public RoundedButton(String label) {
                super(label);
                setContentAreaFilled(false);
                setOpaque(true);
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                if (getModel().isArmed()) {
                    g2d.setColor(getBackground().darker());
                } else {
                    g2d.setColor(getBackground());
                }
                g2d.fill(new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20));

                g2d.setColor(getForeground());
                FontMetrics fm = g2d.getFontMetrics();
                Rectangle textRect = fm.getStringBounds(getText(), g2d).getBounds();
                int x = (getWidth() - textRect.width) / 2;
                int y = (getHeight() - textRect.height) / 2 + fm.getAscent();
                g2d.drawString(getText(), x, y);

                g2d.dispose();
            }

            @Override
            protected void paintBorder(Graphics g) {
                // No need to paint border
            }

            @Override
            public boolean contains(int x, int y) {
                Shape shape = new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                return shape.contains(x, y);
            }
        }

        RoundedButton searchButton = new RoundedButton("Next");
        searchButton.setBounds(640, 260, 100, 30);
        searchButton.setFont(new Font("Arial", Font.BOLD, 14));
        searchButton.setBackground(new Color(28, 175, 207));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fromLocation = (String) fromComboBox.getSelectedItem();
                String toLocation = (String) toComboBox.getSelectedItem();

                // Validate input fields
                if (fromLocation.equals("Select a location") || toLocation.equals("Select a location")) {
                    JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "Please select both 'From' and 'To' locations.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (fromLocation.equals(toLocation)) {
                    JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "The 'From' and 'To' destinations cannot be the same.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                LocalDate departDate = LocalDate.of((int) departYearComboBox.getSelectedItem(), departMonthComboBox.getSelectedIndex() + 1, (int) departDayComboBox.getSelectedItem());
                LocalDate currentDate = LocalDate.now();
                if (departDate.isBefore(currentDate)) {
                    JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "Departure date cannot be in the past.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (roundTrip.isSelected()) {
                    LocalDate returnDate = LocalDate.of((int) returnYearComboBox.getSelectedItem(), returnMonthComboBox.getSelectedIndex() + 1, (int) returnDayComboBox.getSelectedItem());
                    if (returnDate.isBefore(currentDate)) {
                        JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "Return date cannot be in the past.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (returnDate.isEqual(departDate)) {
                        JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "Return date cannot be the same as departure date.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    if (departDate.isAfter(returnDate)) {
                        JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(tripPanel), "Departure date cannot be after return date.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                // If all validations pass, switch to the next panel
                busTicketingSystem.switchToBookSeatPanel();
            }
        });
        tripPanel.add(searchButton);

        return tripPanel;
    }
}
