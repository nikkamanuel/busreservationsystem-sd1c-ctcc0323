import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.imageio.ImageIO;

public class PaymentPanel extends JPanel {

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField cardNumberField;
    private JTextField expirationDateField;
    private JTextField ccvField;
    private JButton completeOrderButton;

    private JLabel firstNameErrorLabel;
    private JLabel lastNameErrorLabel;
    private JLabel cardNumberErrorLabel;
    private JLabel expirationDateErrorLabel;
    private JLabel ccvErrorLabel;

    private BusTicketingSystem parentFrame; // Reference to the main frame

    public PaymentPanel(BusTicketingSystem parentFrame) {
        this.parentFrame = parentFrame; // Initialize reference to the main frame
        setLayout(new BorderLayout()); // Use BorderLayout for the main panel

        JPanel centerPanel = new JPanel(new GridBagLayout()); // Panel to center content
        GridBagConstraints gbc = new GridBagConstraints();
        centerPanel.setBackground(Color.WHITE); // Set background color

        JPanel qrEwalletPanel = createQrEwalletPanel(); // Create QR and E-wallets panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.fill = GridBagConstraints.BOTH;
        centerPanel.add(qrEwalletPanel, gbc);

        JPanel cardDetailsPanel = createCardDetailsPanel(); // Create Card details panel
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        centerPanel.add(cardDetailsPanel, gbc);

        add(centerPanel, BorderLayout.CENTER);

        setPreferredSize(new Dimension(900, 400)); // Set preferred size of the panel
    }

    private JPanel createQrEwalletPanel() {
        JPanel qrEwalletPanel = new JPanel(new BorderLayout());
        qrEwalletPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel qrEwalletTitle = new JLabel("QR and E-wallets");
        qrEwalletTitle.setHorizontalAlignment(SwingConstants.CENTER);
        qrEwalletPanel.add(qrEwalletTitle, BorderLayout.NORTH);

        JPanel imagePanelLeft = new JPanel(new GridLayout(4, 1, 10, 10));

        try {
            imagePanelLeft.add(createClickableImageLabel("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\Maya.png", "https://www.maya.ph"));
            imagePanelLeft.add(createClickableImageLabel("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\GCash.png", "https://www.gcash.com"));
            imagePanelLeft.add(createClickableImageLabel("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\ShopeePay.png", "https://www.shopeepay.com"));
            imagePanelLeft.add(createClickableImageLabel("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\QRPh.png", "https://www.qrph.ph"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        qrEwalletPanel.add(imagePanelLeft, BorderLayout.CENTER);

        return qrEwalletPanel;
    }

    private JPanel createCardDetailsPanel() {
        JPanel cardDetailsPanel = new JPanel(new GridBagLayout());
        cardDetailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel cardDetailsTitle = new JLabel("Debit/Credit Card");
        cardDetailsTitle.setHorizontalAlignment(SwingConstants.CENTER);
        cardDetailsPanel.add(cardDetailsTitle, gbc);
        gbc.gridy++;

        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel firstNameLabel = new JLabel("First Name: ");
        cardDetailsPanel.add(firstNameLabel, gbc);

        firstNameField = new JTextField(15);
        gbc.gridx++;
        cardDetailsPanel.add(firstNameField, gbc);

        firstNameErrorLabel = new JLabel();
        firstNameErrorLabel.setForeground(Color.RED);
        gbc.gridx++;
        cardDetailsPanel.add(firstNameErrorLabel, gbc);
        gbc.gridy++;
        gbc.gridx = 0;

        JLabel lastNameLabel = new JLabel("Last Name: ");
        cardDetailsPanel.add(lastNameLabel, gbc);

        lastNameField = new JTextField(15);
        gbc.gridx++;
        cardDetailsPanel.add(lastNameField, gbc);

        lastNameErrorLabel = new JLabel();
        lastNameErrorLabel.setForeground(Color.RED);
        gbc.gridx++;
        cardDetailsPanel.add(lastNameErrorLabel, gbc);
        gbc.gridy++;
        gbc.gridx = 0;

        JLabel cardNumberLabel = new JLabel("Card Number: ");
        cardDetailsPanel.add(cardNumberLabel, gbc);

        cardNumberField = new JTextField(15);
        gbc.gridx++;
        cardDetailsPanel.add(cardNumberField, gbc);

        cardNumberErrorLabel = new JLabel();
        cardNumberErrorLabel.setForeground(Color.RED);
        gbc.gridx++;
        cardDetailsPanel.add(cardNumberErrorLabel, gbc);
        gbc.gridy++;
        gbc.gridx = 0;

        JLabel expirationDateLabel = new JLabel("Expiration Date : ");
        cardDetailsPanel.add(expirationDateLabel, gbc);

        expirationDateField = new JTextField(15);
        gbc.gridx++;
        cardDetailsPanel.add(expirationDateField, gbc);

        expirationDateErrorLabel = new JLabel();
        expirationDateErrorLabel.setForeground(Color.RED);
        gbc.gridx++;
        cardDetailsPanel.add(expirationDateErrorLabel, gbc);
        gbc.gridy++;
        gbc.gridx = 0;

        JLabel ccvLabel = new JLabel("CCV: ");
        cardDetailsPanel.add(ccvLabel, gbc);

        ccvField = new JTextField(15);
        gbc.gridx++;
        cardDetailsPanel.add(ccvField, gbc);

        ccvErrorLabel = new JLabel();
        ccvErrorLabel.setForeground(Color.RED);
        gbc.gridx++;
        cardDetailsPanel.add(ccvErrorLabel, gbc);
        gbc.gridy++;
        gbc.gridx = 0;

        completeOrderButton = new JButton("Complete Order");
        gbc.gridwidth = 3; // span across three columns
        gbc.gridx++;
        gbc.anchor = GridBagConstraints.CENTER; // align button to the center
        cardDetailsPanel.add(completeOrderButton, gbc);

        completeOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validateFields()) {
                    JOptionPane.showMessageDialog(PaymentPanel.this, "Order completed!");
                    enableAndSwitchDownloadTicketTab(); // Call method to switch to Download Ticket tab
                } else {
                    JOptionPane.showMessageDialog(PaymentPanel.this, "Please fill in all required fields correctly.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return cardDetailsPanel;
    }

    private JLabel createClickableImageLabel(String imagePath, final String link) throws IOException {
        BufferedImage img = ImageIO.read(new File(imagePath));
        Image scaledImg = img.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon icon = new ImageIcon(scaledImg);

        JLabel label = new JLabel(icon);

        label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                try {
                    Desktop.getDesktop().browse(new URI(link));
                } catch (IOException | java.net.URISyntaxException e) {
                    e.printStackTrace();
                }
            }
        });

        return label;
    }

    private boolean validateFields() {
        boolean isValid = true;

        if (firstNameField.getText().trim().isEmpty()) {
            firstNameErrorLabel.setText("Please enter first name");
            isValid = false;
        } else {
            firstNameErrorLabel.setText("");
        }

        if (lastNameField.getText().trim().isEmpty()) {
            lastNameErrorLabel.setText("Please enter last name");
            isValid = false;
        } else {
            lastNameErrorLabel.setText("");
        }

        String cardNumber = cardNumberField.getText().trim();
        if (cardNumber.isEmpty()) {
            cardNumberErrorLabel.setText("Please enter card number");
            isValid = false;
        } else if (!cardNumber.matches("\\d{10,12}")) {
            cardNumberErrorLabel.setText("Card number must be 10-12 digits");
            isValid = false;
        } else {
            cardNumberErrorLabel.setText("");
        }

        String expirationDate = expirationDateField.getText().trim();
        if (expirationDate.isEmpty()) {
            expirationDateErrorLabel.setText("Please enter expiration date");
            isValid = false;
        } else {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");
                LocalDate expDate = LocalDate.parse("01/" + expirationDate, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                if (expDate.isBefore(LocalDate.now())) {
                    expirationDateErrorLabel.setText("Expiration date must be in the future");
                    isValid = false;
                } else {
                    expirationDateErrorLabel.setText("");
                }
            } catch (DateTimeParseException e) {
                expirationDateErrorLabel.setText("Invalid date format (MM/YYYY)");
                isValid = false;
            }
        }

        String ccv = ccvField.getText().trim();
        if (ccv.isEmpty()) {
            ccvErrorLabel.setText("Please enter CCV");
            isValid = false;
        } else if (!ccv.matches("\\d{3,4}")) {
            ccvErrorLabel.setText("CCV must be 3-4 digits");
            isValid = false;
        } else {
            ccvErrorLabel.setText("");
        }

        return isValid;
    }

    private void enableAndSwitchDownloadTicketTab() {
        parentFrame.switchToDownloadTicketPanel(); // Call the method in BusTicketingSystem to switch tab
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BusTicketingSystem frame = new BusTicketingSystem();
            PaymentPanel paymentPanel = new PaymentPanel(frame);
            frame.getContentPane().add(paymentPanel);
        });
    }
}
