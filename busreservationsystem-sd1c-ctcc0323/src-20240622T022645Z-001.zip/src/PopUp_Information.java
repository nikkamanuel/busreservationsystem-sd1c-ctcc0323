import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.RoundRectangle2D;
import javax.swing.plaf.basic.BasicButtonUI;

public class PopUp_Information {

    private Color tealColor = new Color(28, 175, 207);
    private Color whiteColor = Color.WHITE;
    private Color grayColor = new Color(200, 200, 200);

    private JCheckBox termsCheckbox;
    private JButton confirmButton;

    // Callback interface for confirmation completion
    public interface ConfirmationCallback {
        void confirmationComplete();
    }

    private ConfirmationCallback confirmationCallback;

    public void setConfirmationCallback(ConfirmationCallback callback) {
        this.confirmationCallback = callback;
    }

    private JFrame frame; // Store reference to the dialog frame

    // Reference to the parent frame (assuming it's BusTicketingSystem or similar)
    private BusTicketingSystem parentFrame;

    public PopUp_Information(BusTicketingSystem parentFrame, String date, String route, String boardingPoint,
                             String droppingPoint, String seatNumbers, String departureTime,
                             String passengerName, String mobile, String email, String seatNo,
                             int fare, int reservationFee, int subtotal) {
        this.parentFrame = parentFrame; // Store reference to the parent frame

        frame = new JFrame("Confirmation Details");
        frame.setSize(800, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Dispose on close, not exit
        frame.setLocationRelativeTo(parentFrame); // Set location relative to parent frame

        JPanel panel = new JPanel(new GridLayout(1, 3, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setBackground(whiteColor); // Set background color

        // Column 1: Trip Details
        JPanel tripPanel = createTitledBorderPanel("Trip Details");
        tripPanel.setBackground(whiteColor); // Set background color
        addLabelAndValue(tripPanel, "Date:", "2020 - 17- 24");
        addLabelAndValue(tripPanel, "Route:", route);
        addLabelAndValue(tripPanel, "Boarding Point:", boardingPoint);
        addLabelAndValue(tripPanel, "Dropping Point:", droppingPoint);
        addLabelAndValue(tripPanel, "Seat/s No:", seatNumbers);
        addLabelAndValue(tripPanel, "Departure Time:", departureTime);

        // Column 2: Passenger Information
        JPanel passengerPanel = createTitledBorderPanel("Passenger Information");
        passengerPanel.setBackground(whiteColor); // Set background color
        addLabelAndValue(passengerPanel, "Name:", passengerName);
        addLabelAndValue(passengerPanel, "Mobile:", mobile);
        addLabelAndValue(passengerPanel, "Email:", email);
        addLabelAndValue(passengerPanel, "Seat No:", seatNo);

        // Column 3: Payment Details
        JPanel paymentPanel = createTitledBorderPanel("Payment Details");
        paymentPanel.setBackground(whiteColor); // Set background color
        addLabelAndValue(paymentPanel, "Fare Amount:", "1 passenger x " + fare);
        addLabelAndValue(paymentPanel, "Reservation Fee:", reservationFee + " pesos");
        addLabelAndValue(paymentPanel, "Subtotal:", subtotal + ".00");

        panel.add(tripPanel);
        panel.add(passengerPanel);
        panel.add(paymentPanel);

        // Checkbox and Confirm button
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        bottomPanel.setBackground(whiteColor); // Set background color

        termsCheckbox = new JCheckBox("I confirm the details above.");
        termsCheckbox.setHorizontalAlignment(SwingConstants.LEFT);
        termsCheckbox.setForeground(tealColor); // Set text color
        termsCheckbox.setBackground(whiteColor); // Set background color
        termsCheckbox.setBorderPaintedFlat(true); // Remove border
        termsCheckbox.addItemListener(e -> updateConfirmButtonState());
        bottomPanel.add(termsCheckbox, BorderLayout.WEST);

        confirmButton = new JButton("Confirm");
        confirmButton.setForeground(whiteColor); // Set text color
        confirmButton.setUI(new RoundedButtonUI(tealColor, grayColor)); // Pass grayColor here
        confirmButton.setPreferredSize(new Dimension(100, 30)); // Set button size
        confirmButton.setBorderPainted(false); // Remove border
        confirmButton.setEnabled(false); // Initially disabled
        confirmButton.addActionListener(e -> handleConfirm()); // Add action listener for button click
        bottomPanel.add(confirmButton, BorderLayout.EAST);

        frame.add(panel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true); // Make the frame visible
    }

    private JPanel createTitledBorderPanel(String title) {
        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(tealColor), title,
                SwingConstants.CENTER, SwingConstants.CENTER, new Font("Arial", Font.BOLD, 14), tealColor));
        panel.setBackground(tealColor); // Set background color of the title
        return panel;
    }

    private void addLabelAndValue(JPanel panel, String label, String value) {
        JLabel labelComponent = new JLabel(label);
        JLabel valueComponent = new JLabel(value);
        labelComponent.setForeground(tealColor); // Set text color
        valueComponent.setForeground(Color.BLACK); // Set text color
        JPanel container = new JPanel(new FlowLayout(FlowLayout.LEFT));
        container.setBackground(whiteColor); // Set background color
        container.add(labelComponent);
        container.add(valueComponent);
        panel.add(container);
    }

    // Custom UI for rounded button
    static class RoundedButtonUI extends BasicButtonUI {
        private final Color buttonColor;
        private final Color grayColor;
        private static final int arc = 20; // Adjust the roundness here

        public RoundedButtonUI(Color color, Color grayColor) {
            this.buttonColor = color;
            this.grayColor = grayColor; // Initialize grayColor here
        }

        @Override
        public void paint(Graphics g, JComponent c) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            AbstractButton button = (AbstractButton) c;
            int width = button.getWidth();
            int height = button.getHeight();

            // Create round shape
            Shape shape = new RoundRectangle2D.Float(0, 0, width - 1, height - 1, arc, arc); // Adjusted to fit within bounds
            g2d.setColor(button.isEnabled() ? buttonColor : grayColor); // Use grayColor if disabled
            g2d.fill(shape);

            g2d.setColor(button.getForeground());
            g2d.setFont(c.getFont());

            // Draw text in the center
            FontMetrics fm = g2d.getFontMetrics();
            Rectangle textRect = fm.getStringBounds(button.getText(), g2d).getBounds();
            int x = (width - textRect.width) / 2;
            int y = (height - textRect.height) / 2 + fm.getAscent();
            g2d.drawString(button.getText(), x, y);

            g2d.dispose();
        }

        @Override
        protected void paintButtonPressed(Graphics g, AbstractButton b) {
            // Override if needed for pressed state appearance
        }

        @Override
        protected void installDefaults(AbstractButton b) {
            super.installDefaults(b);
            b.setBackground(UIManager.getColor("Button.background")); // Use UIManager to get default button color
            b.setBorderPainted(false); // Remove border
            b.setFocusPainted(false); // Remove focus indication
            b.setContentAreaFilled(false); // Ensure the entire area is filled with background color
        }
    }

    // Method to update the state of the Confirm button
    private void updateConfirmButtonState() {
        confirmButton.setEnabled(termsCheckbox.isSelected());
    }

    // Method to handle "Confirm" button click
    private void handleConfirm() {
        // Close the confirmation dialog
        frame.dispose();
        // Notify callback that confirmation is complete
        if (confirmationCallback != null) {
            confirmationCallback.confirmationComplete();
        }
        // Enable and switch to Payment tab in the main frame
        enableAndSwitchToPaymentTab();
    }

    // Method to enable and switch to Payment tab in the main frame
    private void enableAndSwitchToPaymentTab() {
        parentFrame.switchToPaymentPanel(); // Replace with actual method in BusTicketingSystem
    }
}
