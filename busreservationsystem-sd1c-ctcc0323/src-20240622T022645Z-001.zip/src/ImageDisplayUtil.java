import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.Image;

public class ImageDisplayUtil {

    public static void main(String[] args) {
        // Display the menu and handle the user choice
        while (true) {
            String[] options = {"About Us", "Tour Packages", "Our Buses", "Contact Us", "Exit"};
            int choice = JOptionPane.showOptionDialog(
                null,
                "Select an option",
                "Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
            );

            if (choice == -1 || choice == 4) {
                // Exit if user closes the dialog or selects "Exit"
                break;
            }

            // Show the corresponding image based on user choice
            switch (choice) {
                case 0:
                    showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\AboutUs.jpg", "About Us");
                    break;
                case 1:
                    showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\TourPackages.jpg", "Tour Packages");
                    break;
                case 2:
                    showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\OurBuses.jpg", "Our Buses");
                    break;
                case 3:
                    showImage("C:\\Users\\Lance Manalansan\\Documents\\NetBeansProjects\\Passenjour\\Photos\\ContactUs.jpg", "Contact Us");
                    break;
            }
        }
    }

    static void showImage(String imagePath, String title) {
        // Load the image
        ImageIcon imageIcon = new ImageIcon(imagePath);

        // Check if the image exists
        if (imageIcon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Image not found: " + imagePath,
                "Error",
                JOptionPane.ERROR_MESSAGE
            );
        } else {
            // Resize the image to fit the panel
            Image image = imageIcon.getImage();
            Image resizedImage = image.getScaledInstance(400, 300, Image.SCALE_SMOOTH);
            imageIcon = new ImageIcon(resizedImage);

            // Create a panel with a fixed size
            JPanel panel = new JPanel();
            panel.setPreferredSize(new Dimension(400, 300));

            // Add the image to the panel
            JLabel label = new JLabel(imageIcon);
            panel.add(label);

            // Display the panel in a dialog
            JOptionPane.showMessageDialog(
                null,
                panel,
                title,
                JOptionPane.PLAIN_MESSAGE
            );
        }
    }
}
